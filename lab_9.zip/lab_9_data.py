import sys

from PyQt5.QtSql import QSqlDatabase, QSqlQuery

# Create the connection
con = QSqlDatabase.addDatabase("QSQLITE")
con.setDatabaseName("contacts.sqlite")

# Open the connection
if not con.open():
    print("Database Error: %s" % con.lastError().databaseText())
    sys.exit(1)

# Create a query and execute it right away using .exec()
createTableQuery = QSqlQuery()
createTableQuery.exec(
    """
    CREATE TABLE contacts (
        id INTEGER PRIMARY KEY AUTOINCREMENT UNIQUE NOT NULL,
        name VARCHAR(40) NOT NULL,
        job VARCHAR(50),
        email VARCHAR(40) NOT NULL,
    )
    """
)

insertTableQuery = QSqlQuery()
insertTableQuery.prepare(
    """
    INSERT INTO contacts (
        name,
        job,
        email
    )
    VALUES (?, ?, ?)
    """
)

data = [
    ("Jordan Badcock", "Pimp", "jdog@pimpstar.com"),
    ("Keith Rogers", "CEO of The Cotton Club", "keet@tcc.com"),
    ("Nicholas O'Quinn", "COO of Tweed", "nickydicky@tweed.com"),
    ("Dylan Owens", "Death Certificate Verifier", "dylpixels@dylscrematorium.com"),
    ("Calem Osmond", "Hair Model", "calemo69@lusciouslocks.com"),
]

# Use .addBindValue() to insert data 
for name, job, email in data:
    insertDataQuery.addBindValue(name)
    insertDataQuery.addBindValue(job)
    insertDataQuery.addBindValue(email)
    insertDataQuery.exec()

con.close()